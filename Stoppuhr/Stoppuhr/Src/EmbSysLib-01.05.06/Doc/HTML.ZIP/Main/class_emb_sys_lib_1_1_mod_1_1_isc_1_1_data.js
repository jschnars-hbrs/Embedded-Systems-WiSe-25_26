var class_emb_sys_lib_1_1_mod_1_1_isc_1_1_data =
[
    [ "Data", "class_emb_sys_lib_1_1_mod_1_1_isc_1_1_data.html#a4c924bd5da7a86f29fb82e27a3e10bf3", null ],
    [ "getNext", "class_emb_sys_lib_1_1_mod_1_1_isc_1_1_data.html#a72e63f7e2a17f55e128a3dd069e22e39", null ]
];