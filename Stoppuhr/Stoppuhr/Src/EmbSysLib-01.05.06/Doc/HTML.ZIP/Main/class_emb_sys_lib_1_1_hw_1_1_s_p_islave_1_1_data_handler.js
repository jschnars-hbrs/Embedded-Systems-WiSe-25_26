var class_emb_sys_lib_1_1_hw_1_1_s_p_islave_1_1_data_handler =
[
    [ "transceive", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave_1_1_data_handler.html#aba6cb641ba89670e753ea8d475a374a3", null ]
];