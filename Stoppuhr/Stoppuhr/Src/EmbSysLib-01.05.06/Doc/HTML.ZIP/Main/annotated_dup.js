var annotated_dup =
[
    [ "EmbSysLib", "namespace_emb_sys_lib.html", [
      [ "Ctrl", "namespace_emb_sys_lib_1_1_ctrl.html", [
        [ "DigitalButton", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button" ],
        [ "DigitalEncoder", "class_emb_sys_lib_1_1_ctrl_1_1_digital_encoder.html", "class_emb_sys_lib_1_1_ctrl_1_1_digital_encoder" ],
        [ "DigitalEncoderJoystick", "class_emb_sys_lib_1_1_ctrl_1_1_digital_encoder_joystick.html", "class_emb_sys_lib_1_1_ctrl_1_1_digital_encoder_joystick" ],
        [ "DigitalEncoderRotaryknob", "class_emb_sys_lib_1_1_ctrl_1_1_digital_encoder_rotaryknob.html", "class_emb_sys_lib_1_1_ctrl_1_1_digital_encoder_rotaryknob" ],
        [ "DigitalIndicator", "class_emb_sys_lib_1_1_ctrl_1_1_digital_indicator.html", "class_emb_sys_lib_1_1_ctrl_1_1_digital_indicator" ]
      ] ],
      [ "Dev", "namespace_emb_sys_lib_1_1_dev.html", [
        [ "Analog", "class_emb_sys_lib_1_1_dev_1_1_analog.html", null ],
        [ "AnalogIn", "class_emb_sys_lib_1_1_dev_1_1_analog_in.html", "class_emb_sys_lib_1_1_dev_1_1_analog_in" ],
        [ "AnalogInAdc", "class_emb_sys_lib_1_1_dev_1_1_analog_in_adc.html", "class_emb_sys_lib_1_1_dev_1_1_analog_in_adc" ],
        [ "AnalogOut", "class_emb_sys_lib_1_1_dev_1_1_analog_out.html", "class_emb_sys_lib_1_1_dev_1_1_analog_out" ],
        [ "AnalogOutDac", "class_emb_sys_lib_1_1_dev_1_1_analog_out_dac.html", "class_emb_sys_lib_1_1_dev_1_1_analog_out_dac" ],
        [ "AnalogOutPWM", "class_emb_sys_lib_1_1_dev_1_1_analog_out_p_w_m.html", "class_emb_sys_lib_1_1_dev_1_1_analog_out_p_w_m" ],
        [ "Digital", "class_emb_sys_lib_1_1_dev_1_1_digital.html", "class_emb_sys_lib_1_1_dev_1_1_digital" ],
        [ "Pointer", "class_emb_sys_lib_1_1_dev_1_1_pointer.html", "class_emb_sys_lib_1_1_dev_1_1_pointer" ],
        [ "ScreenChar", "class_emb_sys_lib_1_1_dev_1_1_screen_char.html", "class_emb_sys_lib_1_1_dev_1_1_screen_char" ],
        [ "ScreenGraphic", "class_emb_sys_lib_1_1_dev_1_1_screen_graphic.html", "class_emb_sys_lib_1_1_dev_1_1_screen_graphic" ],
        [ "TaskManager", "class_emb_sys_lib_1_1_dev_1_1_task_manager.html", "class_emb_sys_lib_1_1_dev_1_1_task_manager" ],
        [ "Terminal", "class_emb_sys_lib_1_1_dev_1_1_terminal.html", "class_emb_sys_lib_1_1_dev_1_1_terminal" ]
      ] ],
      [ "Hw", "namespace_emb_sys_lib_1_1_hw.html", [
        [ "EmbSysLib", null, [
          [ "Hw", null, [
            [ "Port", "class_emb_sys_lib_1_1_hw_1_1_emb_sys_lib_1_1_hw_1_1_port.html", "class_emb_sys_lib_1_1_hw_1_1_emb_sys_lib_1_1_hw_1_1_port" ]
          ] ],
          [ "Std", null, [
            [ "Report", "class_emb_sys_lib_1_1_hw_1_1_emb_sys_lib_1_1_std_1_1_report.html", "class_emb_sys_lib_1_1_hw_1_1_emb_sys_lib_1_1_std_1_1_report" ]
          ] ]
        ] ],
        [ "Adc", "class_emb_sys_lib_1_1_hw_1_1_adc.html", "class_emb_sys_lib_1_1_hw_1_1_adc" ],
        [ "Bitmap", "class_emb_sys_lib_1_1_hw_1_1_bitmap.html", "class_emb_sys_lib_1_1_hw_1_1_bitmap" ],
        [ "Dac", "class_emb_sys_lib_1_1_hw_1_1_dac.html", "class_emb_sys_lib_1_1_hw_1_1_dac" ],
        [ "DisplayChar", "class_emb_sys_lib_1_1_hw_1_1_display_char.html", "class_emb_sys_lib_1_1_hw_1_1_display_char" ],
        [ "DisplayChar_DIP204spi", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi" ],
        [ "DisplayChar_Terminal", "class_emb_sys_lib_1_1_hw_1_1_display_char___terminal.html", "class_emb_sys_lib_1_1_hw_1_1_display_char___terminal" ],
        [ "DisplayGraphic", "class_emb_sys_lib_1_1_hw_1_1_display_graphic.html", "class_emb_sys_lib_1_1_hw_1_1_display_graphic" ],
        [ "DisplayGraphic_GRAM", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m" ],
        [ "DisplayGraphic_OTM8009A", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___o_t_m8009_a.html", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___o_t_m8009_a" ],
        [ "DisplayGraphic_OTM8009Acmd", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___o_t_m8009_acmd.html", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___o_t_m8009_acmd" ],
        [ "DisplayGraphic_OTM8009Aram", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___o_t_m8009_aram.html", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___o_t_m8009_aram" ],
        [ "DisplayGraphic_SSD1306i2c", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___s_s_d1306i2c.html", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___s_s_d1306i2c" ],
        [ "DisplayGraphic_SSD2119", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___s_s_d2119.html", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___s_s_d2119" ],
        [ "Encoder", "class_emb_sys_lib_1_1_hw_1_1_encoder.html", "class_emb_sys_lib_1_1_hw_1_1_encoder" ],
        [ "Encoder_Emul", "class_emb_sys_lib_1_1_hw_1_1_encoder___emul.html", "class_emb_sys_lib_1_1_hw_1_1_encoder___emul" ],
        [ "Ethernet", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html", "class_emb_sys_lib_1_1_hw_1_1_ethernet" ],
        [ "Ethernet_ENC28J60", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60" ],
        [ "ExtInt", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html", "class_emb_sys_lib_1_1_hw_1_1_ext_int" ],
        [ "Font", "class_emb_sys_lib_1_1_hw_1_1_font.html", "class_emb_sys_lib_1_1_hw_1_1_font" ],
        [ "I2Cmaster", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster" ],
        [ "I2Cmaster_Emul", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___emul.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___emul" ],
        [ "I2Cslave", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave" ],
        [ "Memory", "class_emb_sys_lib_1_1_hw_1_1_memory.html", "class_emb_sys_lib_1_1_hw_1_1_memory" ],
        [ "Memory_PCF8583", "class_emb_sys_lib_1_1_hw_1_1_memory___p_c_f8583.html", "class_emb_sys_lib_1_1_hw_1_1_memory___p_c_f8583" ],
        [ "MemoryImage", "class_emb_sys_lib_1_1_hw_1_1_memory_image.html", "class_emb_sys_lib_1_1_hw_1_1_memory_image" ],
        [ "Net", "class_emb_sys_lib_1_1_hw_1_1_net.html", "class_emb_sys_lib_1_1_hw_1_1_net" ],
        [ "NetAddr", "class_emb_sys_lib_1_1_hw_1_1_net_addr.html", "class_emb_sys_lib_1_1_hw_1_1_net_addr" ],
        [ "NetEthDHCP", "class_emb_sys_lib_1_1_hw_1_1_net_eth_d_h_c_p.html", "class_emb_sys_lib_1_1_hw_1_1_net_eth_d_h_c_p" ],
        [ "NetEthICMP", "class_emb_sys_lib_1_1_hw_1_1_net_eth_i_c_m_p.html", "class_emb_sys_lib_1_1_hw_1_1_net_eth_i_c_m_p" ],
        [ "NetEthIP", "class_emb_sys_lib_1_1_hw_1_1_net_eth_i_p.html", "class_emb_sys_lib_1_1_hw_1_1_net_eth_i_p" ],
        [ "NetEthTCP", "class_emb_sys_lib_1_1_hw_1_1_net_eth_t_c_p.html", "class_emb_sys_lib_1_1_hw_1_1_net_eth_t_c_p" ],
        [ "NetEthTransport", "class_emb_sys_lib_1_1_hw_1_1_net_eth_transport.html", null ],
        [ "NetEthUDP", "class_emb_sys_lib_1_1_hw_1_1_net_eth_u_d_p.html", "class_emb_sys_lib_1_1_hw_1_1_net_eth_u_d_p" ],
        [ "NetSocket", "class_emb_sys_lib_1_1_hw_1_1_net_socket.html", "class_emb_sys_lib_1_1_hw_1_1_net_socket" ],
        [ "NetType", "class_emb_sys_lib_1_1_hw_1_1_net_type.html", "class_emb_sys_lib_1_1_hw_1_1_net_type" ],
        [ "Port", "class_emb_sys_lib_1_1_hw_1_1_port.html", "class_emb_sys_lib_1_1_hw_1_1_port" ],
        [ "Port_PCF8574", "class_emb_sys_lib_1_1_hw_1_1_port___p_c_f8574.html", "class_emb_sys_lib_1_1_hw_1_1_port___p_c_f8574" ],
        [ "ReportID_Hw", "class_emb_sys_lib_1_1_hw_1_1_report_i_d___hw.html", "class_emb_sys_lib_1_1_hw_1_1_report_i_d___hw" ],
        [ "Rtc", "class_emb_sys_lib_1_1_hw_1_1_rtc.html", "class_emb_sys_lib_1_1_hw_1_1_rtc" ],
        [ "Rtc_PCF8583", "class_emb_sys_lib_1_1_hw_1_1_rtc___p_c_f8583.html", "class_emb_sys_lib_1_1_hw_1_1_rtc___p_c_f8583" ],
        [ "SPImaster", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster.html", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster" ],
        [ "SPIslave", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave.html", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave" ],
        [ "Timer", "class_emb_sys_lib_1_1_hw_1_1_timer.html", "class_emb_sys_lib_1_1_hw_1_1_timer" ],
        [ "Touch", "class_emb_sys_lib_1_1_hw_1_1_touch.html", "class_emb_sys_lib_1_1_hw_1_1_touch" ],
        [ "Touch_FT5336", "class_emb_sys_lib_1_1_hw_1_1_touch___f_t5336.html", "class_emb_sys_lib_1_1_hw_1_1_touch___f_t5336" ],
        [ "Touch_FT6206", "class_emb_sys_lib_1_1_hw_1_1_touch___f_t6206.html", "class_emb_sys_lib_1_1_hw_1_1_touch___f_t6206" ],
        [ "Touch_STMPE811i2c", "class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c.html", "class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c" ],
        [ "Uart", "class_emb_sys_lib_1_1_hw_1_1_uart.html", "class_emb_sys_lib_1_1_hw_1_1_uart" ],
        [ "USBdevice", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice.html", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice" ],
        [ "USBdeviceControl", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice_control.html", null ],
        [ "USBdeviceDescriptor", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice_descriptor.html", null ],
        [ "USBdeviceEndpoint", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice_endpoint.html", null ],
        [ "USBdeviceInterface", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice_interface.html", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice_interface" ],
        [ "USBhost", "class_emb_sys_lib_1_1_hw_1_1_u_s_bhost.html", "class_emb_sys_lib_1_1_hw_1_1_u_s_bhost" ]
      ] ],
      [ "Mod", "namespace_emb_sys_lib_1_1_mod.html", [
        [ "Isc", "class_emb_sys_lib_1_1_mod_1_1_isc.html", "class_emb_sys_lib_1_1_mod_1_1_isc" ],
        [ "Isc_Uart", "class_emb_sys_lib_1_1_mod_1_1_isc___uart.html", "class_emb_sys_lib_1_1_mod_1_1_isc___uart" ],
        [ "Isc_USBdevice", "class_emb_sys_lib_1_1_mod_1_1_isc___u_s_bdevice.html", "class_emb_sys_lib_1_1_mod_1_1_isc___u_s_bdevice" ],
        [ "Isc_USBhost", "class_emb_sys_lib_1_1_mod_1_1_isc___u_s_bhost.html", "class_emb_sys_lib_1_1_mod_1_1_isc___u_s_bhost" ],
        [ "Mqtt", "class_emb_sys_lib_1_1_mod_1_1_mqtt.html", "class_emb_sys_lib_1_1_mod_1_1_mqtt" ],
        [ "MqttClient", "class_emb_sys_lib_1_1_mod_1_1_mqtt_client.html", "class_emb_sys_lib_1_1_mod_1_1_mqtt_client" ],
        [ "MqttInterf", "class_emb_sys_lib_1_1_mod_1_1_mqtt_interf.html", "class_emb_sys_lib_1_1_mod_1_1_mqtt_interf" ],
        [ "ReportID_Mod", "class_emb_sys_lib_1_1_mod_1_1_report_i_d___mod.html", "class_emb_sys_lib_1_1_mod_1_1_report_i_d___mod" ],
        [ "Rtos", "class_emb_sys_lib_1_1_mod_1_1_rtos.html", "class_emb_sys_lib_1_1_mod_1_1_rtos" ],
        [ "USB_Uart", "class_emb_sys_lib_1_1_mod_1_1_u_s_b___uart.html", "class_emb_sys_lib_1_1_mod_1_1_u_s_b___uart" ],
        [ "USBdeviceSimpleIO", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o" ],
        [ "USBinterfClassHID", "class_emb_sys_lib_1_1_mod_1_1_u_s_binterf_class_h_i_d.html", "class_emb_sys_lib_1_1_mod_1_1_u_s_binterf_class_h_i_d" ]
      ] ],
      [ "Std", "namespace_emb_sys_lib_1_1_std.html", [
        [ "Clock", "class_emb_sys_lib_1_1_std_1_1_clock.html", "class_emb_sys_lib_1_1_std_1_1_clock" ],
        [ "Crc", "class_emb_sys_lib_1_1_std_1_1_crc.html", "class_emb_sys_lib_1_1_std_1_1_crc" ],
        [ "DataPointer", "class_emb_sys_lib_1_1_std_1_1_data_pointer.html", "class_emb_sys_lib_1_1_std_1_1_data_pointer" ],
        [ "Fifo", "class_emb_sys_lib_1_1_std_1_1_fifo.html", "class_emb_sys_lib_1_1_std_1_1_fifo" ],
        [ "Flag", "class_emb_sys_lib_1_1_std_1_1_flag.html", "class_emb_sys_lib_1_1_std_1_1_flag" ],
        [ "Report", "class_emb_sys_lib_1_1_std_1_1_report.html", "class_emb_sys_lib_1_1_std_1_1_report" ],
        [ "Sequence", "class_emb_sys_lib_1_1_std_1_1_sequence.html", "class_emb_sys_lib_1_1_std_1_1_sequence" ],
        [ "SharedMem", "class_emb_sys_lib_1_1_std_1_1_shared_mem.html", "class_emb_sys_lib_1_1_std_1_1_shared_mem" ]
      ] ]
    ] ]
];