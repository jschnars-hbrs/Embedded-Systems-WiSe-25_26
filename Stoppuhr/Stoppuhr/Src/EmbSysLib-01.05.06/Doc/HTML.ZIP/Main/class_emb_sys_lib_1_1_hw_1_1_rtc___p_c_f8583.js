var class_emb_sys_lib_1_1_hw_1_1_rtc___p_c_f8583 =
[
    [ "Rtc_PCF8583", "class_emb_sys_lib_1_1_hw_1_1_rtc___p_c_f8583.html#aa380667b8e186ef6933d1fa8ca041776", null ],
    [ "set", "class_emb_sys_lib_1_1_hw_1_1_rtc___p_c_f8583.html#ab6c835661716bf50b807a47f1cce95ba", null ],
    [ "get", "class_emb_sys_lib_1_1_hw_1_1_rtc___p_c_f8583.html#abd0f3f4dd84c73b7abc8bd60d2574792", null ]
];