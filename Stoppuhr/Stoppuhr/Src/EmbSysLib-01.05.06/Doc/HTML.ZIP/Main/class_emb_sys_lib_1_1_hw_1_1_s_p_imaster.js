var class_emb_sys_lib_1_1_hw_1_1_s_p_imaster =
[
    [ "Device", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster_1_1_device.html", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster_1_1_device" ],
    [ "ClockPolPha", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster.html#ac3159d0dc15ed73e054c4d9e343ef073", [
      [ "CPOL_L_CPHA_L", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster.html#ac3159d0dc15ed73e054c4d9e343ef073a30b44405f6042f85fb0b6ad4467f0949", null ],
      [ "CPOL_L_CPHA_H", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster.html#ac3159d0dc15ed73e054c4d9e343ef073ae5f86566457d000c1296731671830e5e", null ],
      [ "CPOL_H_CPHA_L", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster.html#ac3159d0dc15ed73e054c4d9e343ef073a736d453ce7d553f015f3ddd82683a18a", null ],
      [ "CPOL_H_CPHA_H", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster.html#ac3159d0dc15ed73e054c4d9e343ef073aa6a443fcb8294c15eb70748572fc2df8", null ]
    ] ]
];