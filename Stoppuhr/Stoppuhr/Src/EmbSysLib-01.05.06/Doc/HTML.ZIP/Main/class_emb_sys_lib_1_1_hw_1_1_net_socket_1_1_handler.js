var class_emb_sys_lib_1_1_hw_1_1_net_socket_1_1_handler =
[
    [ "onReceive", "class_emb_sys_lib_1_1_hw_1_1_net_socket_1_1_handler.html#a81af436ca637ef8272897d58c111bbde", null ]
];