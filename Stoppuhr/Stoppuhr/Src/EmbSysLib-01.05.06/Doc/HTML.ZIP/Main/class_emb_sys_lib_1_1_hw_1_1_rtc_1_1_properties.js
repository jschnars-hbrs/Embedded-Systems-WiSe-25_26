var class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties =
[
    [ "year", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#a4a6fc53e8955a835b6ec3c37a45c0423", null ],
    [ "month", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#a5374b9a7cf6e086fe83cfcbd44da5da1", null ],
    [ "day", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#aceff6e3ed11dc965104f0ebe441b082d", null ],
    [ "dow", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#abaacb6bb6d6a87fa92c92938ebab4dbe", null ],
    [ "hour", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#a13ff90a40badb724d74133c6b8021a86", null ],
    [ "minute", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#a4e84432f968c64b0c4bda838c271e5af", null ],
    [ "second", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#a01316a402fdf32fc42141408fcdc4eb1", null ]
];