var class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi =
[
    [ "DisplayChar_DIP204spi", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#ae3f4df87c4498a63b4f55b11ab4a42c4", null ],
    [ "clear", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#ae683fe63c33c388e9ba1c6392dd477eb", null ],
    [ "refresh", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#af3e97b40a2e10bc85ca3f8662257b957", null ],
    [ "gotoTextPos", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#a620d2ef504c3d731029356944d360d24", null ],
    [ "putChar", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#aaac5dd9e012b5fa09707361d1785a7da", null ],
    [ "putString", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#ab48ec597ac9a6234433822b695e4898d", null ],
    [ "getNumberOfLines", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#afcebc2be15f272ca91ecb1e9a7224a95", null ],
    [ "getNumberOfColumns", "class_emb_sys_lib_1_1_hw_1_1_display_char___d_i_p204spi.html#a0efe0f8a9325297dc205d4639bf57b87", null ]
];