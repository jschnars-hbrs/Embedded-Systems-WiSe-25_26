var class_emb_sys_lib_1_1_mod_1_1_isc =
[
    [ "Data", "class_emb_sys_lib_1_1_mod_1_1_isc_1_1_data.html", "class_emb_sys_lib_1_1_mod_1_1_isc_1_1_data" ],
    [ "isConnected", "class_emb_sys_lib_1_1_mod_1_1_isc.html#a06bb1fa6e8479023b2bc6054ef7a21a8", null ],
    [ "update", "class_emb_sys_lib_1_1_mod_1_1_isc.html#ab5a3cb47c0d5985f0a73944936a691fa", null ]
];