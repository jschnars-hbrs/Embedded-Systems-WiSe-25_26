var class_emb_sys_lib_1_1_hw_1_1_i2_cmaster =
[
    [ "Device", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster_1_1_device.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster_1_1_device" ]
];