var class_emb_sys_lib_1_1_dev_1_1_pointer =
[
    [ "Data", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data" ],
    [ "Pointer", "class_emb_sys_lib_1_1_dev_1_1_pointer.html#a6bb221ce9547585b48c30ed3e834deb2", null ],
    [ "get", "class_emb_sys_lib_1_1_dev_1_1_pointer.html#a3eb106b834dfb672e52b017344e616dd", null ]
];