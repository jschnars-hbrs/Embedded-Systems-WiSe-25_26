var class_emb_sys_lib_1_1_ctrl_1_1_digital_button =
[
    [ "Action", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#a8bb1ef53467e4f61410d12822d922498", [
      [ "NONE", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#a8bb1ef53467e4f61410d12822d922498ac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "ACTIVATED", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#a8bb1ef53467e4f61410d12822d922498a84b328a7ebdea4c8c4ed62e035ada28d", null ],
      [ "SHORT", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#a8bb1ef53467e4f61410d12822d922498a7a1fe3ba88f0c16cb494922948a9597d", null ],
      [ "LONG", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#a8bb1ef53467e4f61410d12822d922498aaee055c4a5aba7d55774e4f1c01dacea", null ]
    ] ],
    [ "DigitalButton", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#ac04eafdb9a24404f03ee3d7992de1a77", null ],
    [ "getAction", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#ae58e4a4b72541cbdcd4e3376a2a45086", null ],
    [ "getNext", "class_emb_sys_lib_1_1_ctrl_1_1_digital_button.html#a72e63f7e2a17f55e128a3dd069e22e39", null ]
];