var class_emb_sys_lib_1_1_dev_1_1_task_manager =
[
    [ "Clock", "class_emb_sys_lib_1_1_dev_1_1_task_manager_1_1_clock.html", "class_emb_sys_lib_1_1_dev_1_1_task_manager_1_1_clock" ],
    [ "Task", "class_emb_sys_lib_1_1_dev_1_1_task_manager_1_1_task.html", "class_emb_sys_lib_1_1_dev_1_1_task_manager_1_1_task" ],
    [ "TaskManager", "class_emb_sys_lib_1_1_dev_1_1_task_manager.html#ae7809664ea10df8c1c8c687150c992b6", null ],
    [ "add", "class_emb_sys_lib_1_1_dev_1_1_task_manager.html#a300e8db1a0a99d712e3eeba8cc1c5109", null ],
    [ "getCycleTime", "class_emb_sys_lib_1_1_dev_1_1_task_manager.html#ad11c3b5962c5259b6f8592198f7b9725", null ],
    [ "getTics", "class_emb_sys_lib_1_1_dev_1_1_task_manager.html#a2250e79a12a716f8b91f73a116508ed8", null ],
    [ "getNext", "class_emb_sys_lib_1_1_dev_1_1_task_manager.html#a72e63f7e2a17f55e128a3dd069e22e39", null ]
];