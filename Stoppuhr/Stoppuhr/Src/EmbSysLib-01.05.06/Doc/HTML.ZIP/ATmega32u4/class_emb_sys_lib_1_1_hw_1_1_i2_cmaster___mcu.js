var class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu =
[
    [ "I2Cmaster_Mcu", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu.html#a760ebe301c9e8c9ea49b5aff83b43ce8", null ]
];