var class_emb_sys_lib_1_1_hw_1_1_i2_cslave__0 =
[
    [ "I2Cslave_0", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave__0.html#acd8329037fdf24e11e42a4e06fcd4466", null ],
    [ "isr", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave__0.html#ad3e2cce382fecc7f64e5a96f2900e7ff", null ]
];