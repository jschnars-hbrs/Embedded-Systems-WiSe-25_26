var class_emb_sys_lib_1_1_hw_1_1_s_p_islave__0 =
[
    [ "SPIslave_0", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave__0.html#ad9b19b5262b108345824ad06aa019d1f", null ]
];