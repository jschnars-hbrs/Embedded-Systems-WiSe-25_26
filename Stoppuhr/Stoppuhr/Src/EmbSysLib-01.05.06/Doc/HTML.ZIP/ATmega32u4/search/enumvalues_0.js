var searchData=
[
  ['cr_5f1000khz_0',['CR_1000kHz',['../class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45abd742bf65ea29182038b7a9a250a6639',1,'EmbSysLib::Hw::SPImaster_0']]],
  ['cr_5f2000khz_1',['CR_2000kHz',['../class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45a8d201c7f1ef8eed89aace338285ad58d',1,'EmbSysLib::Hw::SPImaster_0']]],
  ['cr_5f250khz_2',['CR_250kHz',['../class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45ac3c0ee155f70081899ebc20ce6e03697',1,'EmbSysLib::Hw::SPImaster_0']]],
  ['cr_5f4000khz_3',['CR_4000kHz',['../class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45a1349159ed26b65772ac7e5c860231cd3',1,'EmbSysLib::Hw::SPImaster_0']]],
  ['cr_5f500khz_4',['CR_500kHz',['../class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45ae7c23dcccfcb7ae865967711bb61eb70',1,'EmbSysLib::Hw::SPImaster_0']]],
  ['cr_5f8000khz_5',['CR_8000kHz',['../class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45a92dd91b4a9aea100a744f87cd02f7081',1,'EmbSysLib::Hw::SPImaster_0']]]
];
