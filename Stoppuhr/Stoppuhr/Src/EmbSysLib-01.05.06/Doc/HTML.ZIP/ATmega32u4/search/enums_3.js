var searchData=
[
  ['spi_5fbaudrate_0',['SPI_Baudrate',['../class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45',1,'EmbSysLib::Hw::SPImaster_0']]]
];
