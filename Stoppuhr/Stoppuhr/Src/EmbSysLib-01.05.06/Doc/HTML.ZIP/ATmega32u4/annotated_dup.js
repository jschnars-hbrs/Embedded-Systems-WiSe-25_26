var annotated_dup =
[
    [ "EmbSysLib", null, [
      [ "Hw", null, [
        [ "Adc_Mcu", "class_emb_sys_lib_1_1_hw_1_1_adc___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_adc___mcu" ],
        [ "I2Cmaster_Mcu", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu" ],
        [ "I2Cslave_0", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave__0.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave__0" ],
        [ "Memory_EEPROM", "class_emb_sys_lib_1_1_hw_1_1_memory___e_e_p_r_o_m.html", "class_emb_sys_lib_1_1_hw_1_1_memory___e_e_p_r_o_m" ],
        [ "PinConfig", "class_emb_sys_lib_1_1_hw_1_1_pin_config.html", "class_emb_sys_lib_1_1_hw_1_1_pin_config" ],
        [ "Port_Mcu", "class_emb_sys_lib_1_1_hw_1_1_port___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_port___mcu" ],
        [ "Rtos_Mcu", "class_emb_sys_lib_1_1_hw_1_1_rtos___mcu.html", null ],
        [ "SPImaster_0", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0" ],
        [ "SPIslave_0", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave__0.html", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave__0" ],
        [ "System", "class_emb_sys_lib_1_1_hw_1_1_system.html", "class_emb_sys_lib_1_1_hw_1_1_system" ],
        [ "Timer_0", "class_emb_sys_lib_1_1_hw_1_1_timer__0.html", "class_emb_sys_lib_1_1_hw_1_1_timer__0" ],
        [ "Timer_1", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html", "class_emb_sys_lib_1_1_hw_1_1_timer__1" ],
        [ "Timer_3", "class_emb_sys_lib_1_1_hw_1_1_timer__3.html", "class_emb_sys_lib_1_1_hw_1_1_timer__3" ],
        [ "Timer_4", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html", "class_emb_sys_lib_1_1_hw_1_1_timer__4" ],
        [ "Timer_Mcu", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu" ],
        [ "Uart_1", "class_emb_sys_lib_1_1_hw_1_1_uart__1.html", "class_emb_sys_lib_1_1_hw_1_1_uart__1" ],
        [ "USBdevice_Mcu", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice___mcu" ]
      ] ]
    ] ]
];