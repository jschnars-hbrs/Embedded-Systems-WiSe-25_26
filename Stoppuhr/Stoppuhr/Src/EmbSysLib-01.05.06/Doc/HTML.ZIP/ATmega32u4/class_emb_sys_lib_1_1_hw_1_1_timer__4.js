var class_emb_sys_lib_1_1_hw_1_1_timer__4 =
[
    [ "Channel", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#a1ce9b523fd4f3b5bbcadcd796183455a", [
      [ "OC4A", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#a1ce9b523fd4f3b5bbcadcd796183455aa2eb396c55cd01e7e2d9dfd8127a92afb", null ],
      [ "OC4B", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#a1ce9b523fd4f3b5bbcadcd796183455aa9260b680227611a256e7b2debd4d39f3", null ],
      [ "OC4D", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#a1ce9b523fd4f3b5bbcadcd796183455aacfa82e9b82996bcc6d7134ade9d0e831", null ]
    ] ],
    [ "PWM_MODE", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#ae99d8592e5fac21551d240db82849d09", [
      [ "INTERRUPT", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#ae99d8592e5fac21551d240db82849d09ad5f5c57f205afd4f9df70a8c4e194b45", null ],
      [ "PWM", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#ae99d8592e5fac21551d240db82849d09aef99a276e1f3b62b5df98acc27b38028", null ],
      [ "PWM_INTERRUPT", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#ae99d8592e5fac21551d240db82849d09ad4d976bdfc53ead56c0f3430e1d309b1", null ]
    ] ],
    [ "Timer_4", "class_emb_sys_lib_1_1_hw_1_1_timer__4.html#a25b8d880f77d9212c1c3e0d50523fb96", null ]
];